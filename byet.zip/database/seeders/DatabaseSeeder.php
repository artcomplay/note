<?php

namespace Database\Seeders;

use Illuminate\Database\Seeder;
use App\Models\Section;

class DatabaseSeeder extends Seeder
{
    /**
     * Seed the application's database.
     *
     * @return void
     */
    public function run()
    {
        //Section::create(array('name' => 'Учет расходов'));
        //Section::create(array('name' => 'Справочник'));
    }
}
